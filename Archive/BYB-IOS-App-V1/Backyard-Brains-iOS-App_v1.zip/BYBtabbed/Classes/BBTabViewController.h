//
//  BBTabViewController.h
//  Backyard Brains
//
//  Created by Alex Wiltschko on 2/6/10.
//  Modified by Zachary King
//      9-15-2011 Most of the code here was moved elsewhere.
//  Copyright 2010 Backyard Brains. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BBTabViewController : UITabBarController {
}

@end