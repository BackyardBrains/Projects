//
//  PlaybackViewController_iPad.h
//  Backyard Brains
//
//  Created by Zachary King on 8/26/11.
//  Copyright 2011 Backyard Brains. All rights reserved.
//

#import "PlaybackViewController.h"

@interface PlaybackViewController_iPad : PlaybackViewController

@property (nonatomic,retain) IBOutlet UINavigationItem *navItem;

- (IBAction)done:(id)sender;

@end
